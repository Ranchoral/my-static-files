// 霸都丶傲天 2019年10月10日 https://github.com/AJLoveChina/birthday
var config = {
    // 句子的长度可以任意， 你可以写十句话， 二十句话都可以
    // 每句话尽量不要超过15个字,不然展示效果可能不太好
    texts: [
        "亲爱的涵涵",      
        "20岁生日快乐呀！！！",  
        "要是从初一算起的话",
        "今天应该是我给darling过的第九个生日诶",
        "以后每年都要陪你过生日哦",
        "这么多年以来，我见过涵涵",
        "奇怪的样子",
        "可爱的样子",
        "美丽的样子",
        "都是我喜欢的样子",
        "涵涵小朋友不要着急哦",
        "礼物很快就会到的啦",
        "亲爱的涵涵",
        "愿你在青春的画卷上，涂抹无畏与好奇",
        "坚信前路自有慷慨春光",
        "当岁月在指尖流淌，愿你的心依旧澄澈",
        "用期盼和希冀绚烂出一片天地",
        "生日快乐~~",
    ],
    
    imgs: {
        "送给我": "./imgs/songxinxin.jpeg",
        "心爱的姑娘": "./imgs/nothing.jpg",
        "今天是你的生日": "./imgs/shengri.jpeg",
        "这是我们在一起的": "./imgs/zaiyiqi.png",
        "第三个生日！": "./imgs/nothing.jpg",
        "这两年来，我见过你": "./imgs/yangzi.jpeg",
        "奇怪的样子": "./imgs/qiguai.jpg",
        "可爱的样子": "./imgs/keai.jpg",
        "美丽的样子": "./imgs/meili.jpg",
        "都是我喜欢的样子": "./imgs/aixin.jpg",
        "礼物很快就会到的啦": "./imgs/chuo.gif",
        "今年要吃好好的": "./imgs/chihaodian.jpeg",
        "喂饱饱的": "./imgs/weibao.jpeg",
        "然后才有力气干活": "./imgs/nothing.jpg",
        "和想我！": "./imgs/nothing.jpg",
        "生日快乐~~": "./imgs/dangao.jpg"
    },
    
    
    desc: {
        turn_on: "点击这里开始",
        play: "上音乐",
        bannar_coming: "生日快乐！！",
        balloons_flying: "好像还少点东西",
        cake_fadein: "我喜欢戴戴",
        light_candle: "我超级喜欢戴戴",
        wish_message: "哈哈哈哈哈生日快乐啦～",
        story: "查看戴戴给涵涵的信"
    },

    // 结束语
    loveText: '爱你的戴戴'
};
